import numpy as np
import pandas as pd
import random
from sklearn.metrics import mean_squared_error, r2_score

# Load data
calories = pd.read_csv('data/calories.csv')
exercise = pd.read_csv('data/exercise.csv')
print("Calories.csv Columns:", calories.columns)
print("Exercise.csv Columns:", exercise.columns)
# Merge or use relevant columns
# Merge using 'User_ID'
data = pd.merge(calories, exercise, how='inner', on='User_ID')

# Use 'Duration' as the predictor variable (input) and 'Calories' as the target (output)
X = data['Duration']
y = data['Calories']



# --- FITNESS FUNCTION ---
def fitness(solution, X, y):
    """Calculates the Least Squares Error (LSE) for a given solution (weights)."""
    y_pred = X * solution[0] + solution[1]  # Simple linear regression: y = m*x + b
    error = np.sum((y - y_pred) ** 2)  # Least squares error
    return error


# --- GENERATE POPULATION ---
def genPopulation(pop_size, solution_size):
    """Generates a random initial population of solutions."""
    population = []
    for _ in range(pop_size):
        # Random coefficients for [slope, intercept] (m, b)
        solution = np.random.uniform(-10, 10, solution_size)  # Search space: [-10, 10]
        population.append(solution)
    return np.array(population)


# --- SELECT BEST SOLUTIONS ---
def selectBest(population, X, y, num_best=20):
    """Selects the top 'num_best' solutions based on fitness (least error)."""
    fitness_scores = [(sol, fitness(sol, X, y)) for sol in population]
    sorted_population = sorted(fitness_scores, key=lambda x: x[1])
    best_solutions = [sol for sol, _ in sorted_population[:num_best]]
    return np.array(best_solutions)


# --- CROSSOVER OPERATOR ---
def crossover(parent1, parent2):
    """Combines two parents to produce offspring solutions."""
    alpha = random.uniform(0, 1)
    child1 = alpha * parent1 + (1 - alpha) * parent2
    child2 = (1 - alpha) * parent1 + alpha * parent2
    return child1, child2


# --- MUTATION OPERATOR ---
def mutation(solution, mutation_rate=0.1):
    """Applies a small random change to a solution."""
    for i in range(len(solution)):
        if random.random() < mutation_rate:
            solution[i] += np.random.uniform(-0.5, 0.5)  # Small change
    return solution


# --- GENETIC ALGORITHM ---
def geneticAlgorithm(X, y, pop_size=100, generations=50, solution_size=2):
    """Main Genetic Algorithm loop."""
    # Step 1: Generate Initial Population
    population = genPopulation(pop_size, solution_size)

    for generation in range(generations):
        # Step 2: Evaluate and Select Best
        best_solutions = selectBest(population, X, y)

        # Step 3: Crossover
        next_population = []
        for i in range(0, len(best_solutions), 2):
            parent1 = best_solutions[i]
            parent2 = best_solutions[(i + 1) % len(best_solutions)]
            child1, child2 = crossover(parent1, parent2)
            next_population.extend([child1, child2])

        # Step 4: Mutation
        next_population = [mutation(sol) for sol in next_population]

        # Update population
        population = np.array(next_population)

        # Print progress
        best_fitness = fitness(best_solutions[0], X, y)
        print(f"Generation {generation + 1}, Best Fitness: {best_fitness:.4f}")

    # Final best solution
    best_solution = selectBest(population, X, y, num_best=1)[0]
    print("Best Solution (m, b):", best_solution)
    return best_solution


# Run Genetic Algorithm
best_solution = geneticAlgorithm(X, y)


# Define metrics
def calculate_metrics(y_true, y_pred):
    """
    Calculate RMSE, MSE, and R-squared.
    :param y_true: Actual target values
    :param y_pred: Predicted target values
    :return: Dictionary containing RMSE, MSE, and R-squared
    """
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mse = mean_squared_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return {"RMSE": rmse, "MSE": mse, "R2": r2}

# Example usage after Genetic Algorithm finishes:
# Assuming you have the final predictions and true values
y_true = data['Calories'].values  # Replace 'Calories' with actual target column
X_input = data['Duration'].values  # Example input column used in GA (e.g., 'Duration')

# Generate predictions using the best solution (coefficients)
# Assuming best_solution = [intercept, slope] after GA optimization
def predict(best_solution, X):
    return best_solution[0] + best_solution[1] * X

# Example: Final solution obtained from GA
best_solution = [50, 3]  # Example intercept and slope (replace with GA's best solution)
y_pred = predict(best_solution, X_input)

# Calculate metrics
metrics = calculate_metrics(y_true, y_pred)
print("Evaluation Metrics:")
print("RMSE:", metrics['RMSE'])
print("MSE:", metrics['MSE'])
print("R-squared:", metrics['R2'])
